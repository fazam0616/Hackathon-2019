package Game.Ammo;


public class PistolRound extends Ammo{
    public PistolRound(int amount){
        super(10,5, amount);
    }
}
