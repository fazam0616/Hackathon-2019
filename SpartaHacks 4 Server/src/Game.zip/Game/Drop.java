package Game;

import javax.swing.text.Position;
import java.awt.*;

public abstract class Drop {
    public Color color;
    public Position pos;

    public Drop(Color color, Position pos){
        this.color = color;
        this.pos = pos;
    }
    public Drop(){

    }

    public void draw (Graphics g){

    }
}
