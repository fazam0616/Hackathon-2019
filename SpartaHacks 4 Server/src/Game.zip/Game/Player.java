package Game;

import Game.Guns.Gun;

import java.awt.*;

public class Player {
    public int health = 100;
    public Gun[] guns;
    public Point pos;
    public Color color;
    public String username;

    public Player(String name, Color color){
        this.username = name;
        this.color = color;
    }
}
