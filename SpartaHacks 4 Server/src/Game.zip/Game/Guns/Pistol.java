package Game.Guns;

import Game.Ammo.PistolRound;

public class Pistol extends Gun{
    public Pistol(PistolRound ammo){
        super(ammo,1/12);
    }
}
